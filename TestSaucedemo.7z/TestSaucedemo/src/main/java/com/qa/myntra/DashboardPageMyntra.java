package com.qa.myntra;

import java.io.IOException;

public class DashboardPageMyntra extends BaseClass{
	
	
	public DashboardPageMyntra() throws IOException {
		super();
		// TODO Auto-generated constructor stub
	}

	public void method1(){
		
	}

}
