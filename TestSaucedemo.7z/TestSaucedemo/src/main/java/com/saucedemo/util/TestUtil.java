package com.saucedemo.util;

public class TestUtil {
	
	public static long PAGE_LOAD_TIMEOUT=20;
	public static long IMPLICITY_WAIT=20;;

}
